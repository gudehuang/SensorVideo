package com.example.hzg.videovr;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.Mat;
import org.opencv.imgproc.Imgproc;
import org.opencv.videoio.VideoCapture;
import org.opencv.videoio.Videoio;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class ShowActivity extends Activity
        implements SensorEventListener {

    private static final String TAG = "gao_chun";
    private VideoCapture videoCapture;
    private ArrayList<Integer> sensorData;
    private Bitmap bitmap;
    private SensorManager sensorManager;
    private float gravity = 0, pitchangle = 0;
    private int courseangle = 0;
    private int[] i ={0,0,0};
    private int time = 0 ;
    private int screenwidth;
    private ProgressBar progressBar;
    private FrameLayout root;
    private Context context;
    private String Path;
    private Mat mat ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //无title
        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        //全屏
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        Path = getIntent().getStringExtra("path");
        progressBar = (ProgressBar) findViewById(R.id.progressbar);
        root = (FrameLayout) findViewById(R.id.root);
        context = this;
        Log.i(TAG, "Trying to load OpenCV library");
        if (!OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_3_2_0, context, mLoaderCallback)) {
            Log.e(TAG, "Cannot connect to OpenCV Manager");
        } else {
            Log.i(TAG, "connect to OpenCV Manager ");
        }
        sensorManager = (SensorManager) this.getSystemService(Context.SENSOR_SERVICE);
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION),
                sensorManager.SENSOR_DELAY_GAME);
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY),
                sensorManager.SENSOR_DELAY_GAME);

    }

    class PictureTask extends AsyncTask<Void, Integer, Boolean> {

        protected void onPreExecute() {
            progressBar.setProgress(0); // 显示进度对话框
        }

        @Override
        protected Boolean doInBackground(Void... params) {
            mat = new Mat();
            screenwidth = (int) getScreenWidthSize();
            handleVideo();
            System.out.println("finish2");
            return true;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            // 在这里更新下载进度
        }

        @Override
        protected void onPostExecute(Boolean result) {
            progressBar.setVisibility(View.GONE); // 关闭进度对话框
            final MySurfaceView2 mySurfaceView2 = new MySurfaceView2(context);
            root.addView(mySurfaceView2);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    while (true) {
                        Mat mat = SearchMat(courseangle);
                        Utils.matToBitmap(mat, bitmap);
                        mySurfaceView2.show(bitmap, pitchangle, gravity, screenwidth,courseangle);
                    }
                }
            }).start();
        }
    }

    private void handleVideo() {
//        String dataPath = Environment.getExternalStorageDirectory().getPath() + "/360video" + Path;
        String dataPath =  Path;
////                String dataPath = "/storage/sdcard1/testone.avi";

        videoCapture = new VideoCapture(dataPath);
        ObjectInputStream ois = null;
        try {
            ois = new ObjectInputStream(new FileInputStream(dataPath + ".vr"));
            sensorData = (ArrayList<Integer>) ois.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(sensorData);
        bitmap = Bitmap.createBitmap((int) videoCapture.get(Videoio.CAP_PROP_FRAME_WIDTH),
                (int) videoCapture.get(Videoio.CAP_PROP_FRAME_HEIGHT), Bitmap.Config.ARGB_8888);

    }

    private double getScreenWidthSize() {
        Point point = new Point();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            getWindowManager().getDefaultDisplay().getRealSize(point);
        }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        double x = point.x / dm.xdpi;
        x = x * 25.4;
        return x;
    }

    private Mat SearchMat(int angle) {
        int abs;
//        float c = 0 ;
        int a = 0, b = 0;
        if (!sensorData.isEmpty()) {
            a = sensorData.get(0);
//            a = (int) c;
            b = 0;
        }
        abs = a - angle;
        abs = Math.abs(abs);
        for (int i = 1; i < sensorData.size(); i++) {
            a = sensorData.get(i);
//            a = (int) c;
            if (abs > Math.abs(a - angle)) {
                b = i;
                abs = Math.abs(a - angle);
            }
        }
        videoCapture.set(Videoio.CAP_PROP_POS_FRAMES, b);
        videoCapture.read(mat);
        Imgproc.cvtColor(mat, mat, Imgproc.COLOR_BGR2RGB);
        return mat;
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private BaseLoaderCallback mLoaderCallback = new BaseLoaderCallback(this) {
        @Override
        public void onManagerConnected(int status) {
            switch (status) {
                case LoaderCallbackInterface.SUCCESS: {
                    Log.i(TAG, "OpenCV loaded successfully");
                    new PictureTask().execute();
                }
                break;
                default: {
                    super.onManagerConnected(status);
                }
                break;
            }
        }
    };

    @Override
    public void onSensorChanged(SensorEvent event) {
        float[] values = event.values;
        int sensorType = event.sensor.getType();
        switch (sensorType) {
            case Sensor.TYPE_ORIENTATION:
                time++ ;
                float x = values[0];
                float y = values[2];
                i[time % 3] = (int) x;
                if (time > 2)
                    courseangle = (i[0] + i[1] + i[2]) / 3;
                pitchangle = y;
                break;
            case Sensor.TYPE_GRAVITY:
                float z = values[2];
                gravity = z;
                break;
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}