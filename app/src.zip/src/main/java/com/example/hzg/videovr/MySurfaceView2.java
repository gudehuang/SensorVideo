package com.example.hzg.videovr;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

/**
 * Created by william on 2016/11/29.
 */
public class MySurfaceView2 extends SurfaceView implements SurfaceHolder.Callback {
    private SurfaceHolder mHolder;
    private Canvas mCanvas;//用于绘图的canvas
    private Paint mPaint;
    private int w, h;
    private Btn btn;
    private Context context;
    public static boolean ShowBtn = false;
    public static final int COMMON = 0;
    public static final int VR = 2;
    public static final int NEWVR = 1;
    public static int style = 0;
    private Rect mTopSrcRect, mVRDestRect, mCOMDestRect;
    private Bitmap background;

    public MySurfaceView2(Context context) {
        super(context);
        this.context = context;
        initview();
    }

    public MySurfaceView2(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        initview();
    }

    public MySurfaceView2(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.context = context;
        initview();
    }

    private void initview() {
        getHolder().setFormat(PixelFormat.TRANSLUCENT);
        mHolder = getHolder();
        mHolder.addCallback(this);//注册回调
        setFocusable(true);
        setFocusableInTouchMode(true);
        this.setKeepScreenOn(true);
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
        mPaint.setColor(Color.RED);
        mPaint.setTextSize(100);
        background = BitmapFactory.decodeResource(getResources(), R.drawable.background);
    }

    public void show(Bitmap bitmap, float pitchangle, float gravity, double screenwidth, int courseangle) {
        mCanvas = mHolder.lockCanvas();
        if (mCanvas != null)
            mCanvas.drawColor(Color.BLACK);
        if (style % 3 == VR) {
            int PupilDistance = 64;
            int x = (int) (w * (screenwidth / 2 - PupilDistance / 2) * 2 / screenwidth);
            int y = w / bitmap.getWidth() * bitmap.getHeight();
            bitmap = Bitmap.createScaledBitmap(bitmap, x, y, false);
            mVRDestRect = new Rect(0, 0, x, h);
            y = 100;
            mTopSrcRect = new Rect(0, y, x, y + h);
            if (mCanvas != null) {
                mCanvas.drawBitmap(bitmap, mTopSrcRect, mVRDestRect, mPaint);
                mVRDestRect = new Rect(w - x, 0, w, h);
                mCanvas.drawBitmap(bitmap, mTopSrcRect, mVRDestRect, mPaint);

            }

        } else if (style % 3 == COMMON) {
            int x = w;
            int y = w / bitmap.getWidth() * bitmap.getHeight();
            bitmap = Bitmap.createScaledBitmap(bitmap, x, y, false);
            y = 100;
            mTopSrcRect = new Rect(0, y, x, y + h);
            if (mCanvas != null)
                mCanvas.drawBitmap(bitmap, mTopSrcRect, mCOMDestRect, mPaint);
        } else {
            int x = w;
            int y = w / bitmap.getWidth() * bitmap.getHeight();
            bitmap = Bitmap.createScaledBitmap(bitmap, x, y, false);
            bitmap = Bitmap.createBitmap(bitmap, x / 4, 100, x * 3 / 4, h);
            if (mCanvas != null) {
                mCanvas.drawBitmap(bitmap, 0, 0, mPaint);
                mCanvas.drawBitmap(bitmap, w / 2, 0, mPaint);
                mCanvas.drawBitmap(background, 0, 0, mPaint);
            }
        }
        if (mCanvas != null) {
            btn.draw(mCanvas);
            mCanvas.drawText(String.valueOf(courseangle), 100, 100, mPaint);
        }
        if (mCanvas != null)
            mHolder.unlockCanvasAndPost(mCanvas);//对画布内容进行提交

    }

    @Override
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        w = this.getWidth();// 获取屏幕的宽
        h = this.getHeight();// 获取屏幕的高
        background = Bitmap.createScaledBitmap(background, w, h, false);
        btn = new Btn(w, h, context);
        mCOMDestRect = new Rect(0, 0, w, h);
    }

    @Override
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_UP) {
            if (ShowBtn)
                btn.OnTouchEvent(event);
            else
                btn.logic();
        }
        return true;
    }


}

