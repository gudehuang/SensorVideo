package com.example.hzg.videovr;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by hzg on 2017/3/6.
 */

public class TestAct extends AppCompatActivity {
     private  String[] namelist=new String[]{
             "直接处理onPreviewFrame返回的byte[]数据",
             "YUV 转 Rgba 再倒转",
             "不做处理"
     };
     private  Class[] actlist=new Class[]{
             MainActivitytest2.class,
             MainActivitytest3.class,
             MainActivitytest4.class

     };
     private RecyclerView recyclerView;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);
        recyclerView= (RecyclerView) findViewById(R.id.list_act);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new RecyclerView.Adapter<MyViewholder>() {

            @Override
            public MyViewholder onCreateViewHolder(ViewGroup parent, int viewType) {
                View root= LayoutInflater.from(parent.getContext()).inflate(R.layout.list_test,parent,false);
                return new MyViewholder(root);
            }

            @Override
            public void onBindViewHolder(MyViewholder holder, final int position) {
holder.textView.setText(namelist[position]);
                holder.textView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        startActivity(new Intent(TestAct.this,actlist[position]));
                    }
                });
            }

            @Override
            public int getItemCount() {
                return namelist.length;
            }
        });
    }
    class MyViewholder extends RecyclerView.ViewHolder {
        public MyViewholder(View itemView) {
            super(itemView);
            textView= (TextView) itemView.findViewById(R.id.tv_name);
        }
        private TextView textView;
    }
}
