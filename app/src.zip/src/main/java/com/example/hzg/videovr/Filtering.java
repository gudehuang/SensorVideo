package com.example.hzg.videovr;

/**
 * Created by hzg on 2017/3/11.
 */
class Filtering {
    float[] floats;
    int index = 0;
    int size = 0;

    public Filtering(int size) {
        floats = new float[size];
        this.size = size;
    }

    public void put(float sensor) {
        floats[index % size] = sensor;
        index++;
    }

    public float getResult() {
        float sum = 0;
        for (float f : floats) {
            sum += f;
        }
        return sum / size;
    }
}
