package com.example.hzg.videovr;

import android.content.Context;
import android.hardware.Camera;
import android.util.AttributeSet;

/**
 * Created by hzg on 2017/3/6.
 */

public class TestCameraView extends MyCameraView {
    public TestCameraView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public void onPreviewFrame(byte[] frame, Camera arg1) {
        super.onPreviewFrame(frame, arg1);
    }

}
